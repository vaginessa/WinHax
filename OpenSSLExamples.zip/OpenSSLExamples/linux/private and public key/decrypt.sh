read -p "infile: " infile
read -p "outfile: " outfile

openssl rsautl -decrypt -inkey private.key -in $infile -out $outfile
