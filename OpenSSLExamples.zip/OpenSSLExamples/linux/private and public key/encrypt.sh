read -p "inkey: " inkey

openssl rsautl -encrypt -pubin -inkey $inkey -ssl -in secret.txt -out top-secret.txt
