openssl genrsa -des3 -out private.key 2048

sleep 1s

openssl rsa -in private.key -pubout -out public.key
