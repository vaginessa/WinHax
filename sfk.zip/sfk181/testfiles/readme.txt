the whole directory "testfiles" contains just dummy text files
simulating some kind of source code tree.

it's used to demonstrate sfk functionality,
read more in the main readme.txt

[EOD]
