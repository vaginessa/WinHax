/*
   this is a completely pointess text file
   to easily demonstrate sfk functionality.
*/

class Trace
{
public:
    Trace   ( );
   ~Trace   ( );

private:
TraceFile
    *pClFile;
};
