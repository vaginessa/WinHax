/*
   this is a completely pointless text file
   to easily demonstrate sfk functionality.
*/

class DBController
{
public:
      DBController   ( );
     ~DBController   ( );

private:
DBManager
      *pClManager;   
}

