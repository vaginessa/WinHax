/*
   this is a completely pointless text file
   to easily demonstrate sfk functionality.
*/

class FooGUI
{
public:
      FooGUI   ( );
     ~FooGUI   ( );

private:
ColorfulWindow
      *pClWindow;
}

