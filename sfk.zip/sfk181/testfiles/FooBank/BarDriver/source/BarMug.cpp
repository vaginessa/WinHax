/*
   this is a completely pointless text file
   to easily demonstrate sfk functionality.
*/

#include "FooBank/BarDriver/include/ExtremelyLongHeaderFileNameForRatherSeldomUsedClass.hpp"

BarMug::BarMug( )
{
   pClSomething = 0;
}

BarMug::~BarMug( )
{
   if (pClBotte) {
      delete pClSomething = 0;
      pClSomething = 0;
   }
}
