/*
   this is a completely pointless text file
   to easily demonstrate sfk functionality.
*/

BarGlass::BarGlass( )
{
   pClSomething = 0;
}

BarGlass::~BarGlass( )
{
   if (pClBotte) {
      delete pClSomething = 0;
      pClSomething = 0;
   }
}
