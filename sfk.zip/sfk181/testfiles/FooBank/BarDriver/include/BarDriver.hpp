/*
   this is a completely pointess text file
   to easily demonstrate sfk functionality.
*/

class BarDriver
{
public:
    BarDriver   ( );
   ~BarDriver   ( );

    void runDrawThread  ( );

private:
Bottle
   *pClBottle;
};
