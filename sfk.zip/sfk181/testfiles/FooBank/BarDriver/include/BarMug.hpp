/*
   this is a completely pointless text file
   to easily demonstrate sfk functionality.
*/

class BarMug
{
public:
    BarMug   ( );
   ~BarMug   ( );

private:
Something
   *pClSomething;
};
