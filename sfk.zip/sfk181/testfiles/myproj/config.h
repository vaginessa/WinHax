// the myproj config

#define FOO 1
#define BAR 2
#define GOO 3

