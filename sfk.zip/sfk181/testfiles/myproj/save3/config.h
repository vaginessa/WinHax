// the myproj config 
