// general tool functions 
